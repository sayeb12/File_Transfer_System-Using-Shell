
echo "1- List Directories"
echo "2- Create Directory"
echo "3- Total Directories"
echo "4- Total Files in current Directory"
echo "5- Sort Files of the Directory"
echo "6- Delete Directoriy"
echo "7- Search Directoriy"
echo "0- Exit"
