
echo "1- File Lock/Unlock"
echo "2- Directory Lock/Unlock"
echo "3- Archive Large Files"
echo "0- Exit"

