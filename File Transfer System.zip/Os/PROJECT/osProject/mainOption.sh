
echo "1- File Handling"
echo "2- Directory Handling"
echo "3- Advance Options"
echo "0- Exit"

