#!/bin/bash

echo "1- Display Files"
echo "2- Files Creation"
echo "3- File Deletion"
echo "4- Rename File"
echo "5- Edit File"
echo "6- Search File"
echo "7- Details of a File"
echo "8- Display File Content"
echo "9- Sort File Content"
echo "10-Catagorize using extension"
echo "0- Exit"

