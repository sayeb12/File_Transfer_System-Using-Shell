#!/bin/bash

echo "1- List all Files and Directories"
echo "2- Create New Files"
echo "3- Delete Existing Files"
echo "4- Rename Files"
echo "5- Edit File Content"
echo "6- Search Files"
echo "7- Details of Particular File"
echo "8- View Content of File"
echo "9- Sort File Content"
echo "10- List only Directories(Folders)"
echo "0- Exit"

